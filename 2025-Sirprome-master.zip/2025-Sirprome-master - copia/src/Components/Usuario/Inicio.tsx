import { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import "../../assets/Inicio_Secion.css";
import Logo from "../../assets/Logo.jpg";

const GestionUsuario = () => {
  const navigate = useNavigate();
  const { idUsuario } = useParams();
  const [vistaActual, setVistaActual] = useState("inicio");
  const [correo, setCorreo] = useState("");
  const [contraseña, setContraseña] = useState("");
  const [nombre, setNombre] = useState("");
  const [rol, setRol] = useState("");
  const [carga, setCarga] = useState(false);

  useEffect(() => {
    if (vistaActual === "actualizarRol" && (!idUsuario || idUsuario.length !== 36)) {
      alert("Acceso inválido");
      navigate("/");
    }
  }, [vistaActual, idUsuario, navigate]);

  const onIngresar = async () => {
    setCarga(true);
    if (!correo.trim() || !contraseña.trim()) {
      alert("Por favor, completa todos los campos.");
      setCarga(false);
      return;
    }
    const url = "http://localhost:4100/Inicio";
    try {
      const response = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ Correo: correo, Contraseña: contraseña }),
      });
      if (response.ok) {
        const data = await response.json();
        const idUsuario = data.id;
        const rol = data.rol;
        if (!idUsuario) throw new Error("No se recibió un ID válido");
        navigate(rol === "estudiante" ? `/VerGrupos/${idUsuario}` : `/MisGrupos/${idUsuario}`);
      } else {
        alert("Error al iniciar sesión.");
      }
    } catch {
      alert("Error al conectar con el servidor.");
    } finally {
      setCarga(false);
    }
  };

  const onRegistrar = async () => {
    setCarga(true);
    if (!nombre.trim() || !correo.trim() || !contraseña.trim()) {
      alert("Por favor, completa todos los campos.");
      setCarga(false);
      return;
    }
    const url = "http://localhost:4100/Registrar";
    try {
      const response = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ Nombre: nombre, Correo: correo, Contraseña: contraseña }),
      });
      if (response.ok) {
        const data = await response.json();
        navigate(`/Seleccionar-Rol/${data.id}`);
      } else {
        alert("Error al registrar usuario.");
      }
    } catch {
      alert("Error al conectar con el servidor.");
    } finally {
      setCarga(false);
    }
  };

  const onRecuperar = async () => {
    setCarga(true);
    if (!correo.trim()) {
      alert("Por favor, ingresa un correo.");
      setCarga(false);
      return;
    }
    const url = "http://localhost:4100/Recuperar";
    try {
      const response = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ Correo: correo }),
      });
      if (response.ok) {
        alert("Correo enviado para recuperación.");
        setVistaActual("inicio");
      } else {
        alert("Error al recuperar contraseña.");
      }
    } catch {
      alert("Error al conectar con el servidor.");
    } finally {
      setCarga(false);
    }
  };

  const onActualizarRol = async () => {
    setCarga(true);
    if (!rol.trim()) {
      alert("Selecciona un rol.");
      setCarga(false);
      return;
    }
    const url = `http://localhost:4100/ActualizarRol/${idUsuario}`;
    try {
      const response = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ Rol: rol }),
      });
      if (response.ok) {
        navigate(rol === "estudiante" ? `/VerGrupos/${idUsuario}` : `/MisGrupos/${idUsuario}`);
      } else {
        alert("Error al actualizar el rol.");
      }
    } catch {
      alert("Error al conectar con el servidor.");
    } finally {
      setCarga(false);
    }
  };

  return (
    <div className="fondo">
      <div className="contenedor">
        <div className="parte-superior">
          
          {vistaActual === "inicio" && (
            <><div className="fondo-azul">
              <h2 className="titulo-sesion">SIRPROME</h2>
              
              </div>
              <div className="parametros-inicio">
              <div className="subtitulos">Correo Electrónico</div> 
              <input 
                type="email"
                placeholder="usuario@dominio.com" className="Pequeñas-letras"
                value={correo}
                onChange={(e) => setCorreo(e.target.value)}
              />
              <div className="subtitulos">Contraseña</div> 
              <input 
                type="password"
                placeholder="*********" className="Pequeñas-letras"
                value={contraseña}
                onChange={(e) => setContraseña(e.target.value)}
              />
              <button onClick={() => setVistaActual("recuperar")} className="linkBoton1">
                ¿Olvidaste tu contraseña?
              </button>
              </div>
              
              <button onClick={onIngresar} disabled={carga} className="Enter">
                {carga ? "Cargando..." : "Iniciar Sesión"}
              </button>
              <div className="Pregunta">
                ¿No tienes una cuenta?{" "}
                <button onClick={() => setVistaActual("registro")} className="linkBoton2">
                  Regístrate aquí
                </button>
              </div>
            </>
          )}

          {vistaActual === "registro" && (
            <>
              <h1 className="fondo-azul">Registrar Usuario</h1>
              <div className="subtitulos">Nombre</div>
              <input
                type="text"
                placeholder="Ingresa tu nombre completo" className="Pequeñas-letras"
                value={nombre}
                onChange={(e) => setNombre(e.target.value)}
              />
              <div className="subtitulos">Correo</div>
              <input
                type="email"
                placeholder="Ingresa tu correo electrónico" className="Pequeñas-letras"
                value={correo}
                onChange={(e) => setCorreo(e.target.value)}
              />
              <div className="subtitulos">Contraseña</div>
              <input
                type="password"
                placeholder="Crea una contraseña segura" className="Pequeñas-letras"
                value={contraseña}
                onChange={(e) => setContraseña(e.target.value)}
              />
              <div className="Botones-Inicio">
              <button onClick={() => setVistaActual("inicio")} className="Volver-Boton-inicio ">
                Volver
              </button>
              <button onClick={onRegistrar} disabled={carga} className="Enter-Recuperar">
                {carga ? "Cargando..." : "Registrar"}
              </button>
              
              </div>
            </>
          )}

          {vistaActual === "recuperar" && (
            <>
              <h4 className="fondo-azul">Recuperar Contraseña</h4>
              <div className="subtitulos">Correo Electrónico</div> 
              <input
                type="email"
                placeholder="Ingresa tu correo registrado " className="Pequeñas-letras"
                value={correo}
                onChange={(e) => setCorreo(e.target.value)}
              />
              <div className="Botones-Inicio">
              
              <button onClick={() => setVistaActual("inicio")} className="Volver-Boton-inicio ">
                Volver
              </button>
              <button onClick={onRecuperar} disabled={carga} className="Enter-Recuperar">
                {carga ? "Cargando..." : "Recuperar"}
              </button>
              </div>
            </>
          )}

          {vistaActual === "actualizarRol" && (
            <>
              <h4>Actualizar Rol</h4>
              <p>ID Usuario: {idUsuario}</p>
              <button onClick={() => setRol("estudiante")}>Estudiante</button>
              <button onClick={() => setRol("profesor")}>Profesor</button>
              <button onClick={onActualizarRol} disabled={carga}>
                {carga ? "Cargando..." : "Actualizar"}
              </button>
              <button onClick={() => setVistaActual("inicio")}>Volver</button>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default GestionUsuario;
